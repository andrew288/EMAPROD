; <?php exit; ?>
MYSQL_DATABASE_NAME = "emaprod"
MYSQL_USER = "emaprod"
MYSQL_PASSWORD = "Sm~18jn57"