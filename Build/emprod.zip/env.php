; <?php exit; ?>
MYSQL_DATABASE_NAME = "emaprod"
MYSQL_USER = "root"
MYSQL_PASSWORD = "root"